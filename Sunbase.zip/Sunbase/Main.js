const token = localStorage.getItem('access_token');
var usrtoedit = null
console.log('mainjs')

function editCustomer(_user) {
  const user = window.map.get(_user)
  document.getElementById('firstName').value = user.first_name;
  document.getElementById('lastName').value = user.last_name;
  document.getElementById('street').value = user.street;
  document.getElementById('address').value = user.address;
  document.getElementById('city').value = user.city;
  document.getElementById('state').value = user.state;
  document.getElementById('email').value = user.email;
  document.getElementById('phone').value = user.phone;
  // uuid
  document.getElementById('uuid').value = user.uuid;

}

if (token) {
  async function init() {
    const req = await fetch("https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=get_customer_list", {
      headers: {
        "Authorization": `Bearer ${token}`,
      },
      credentials: "include"
    });

    /**temp data from local */
    // const data = await fetch('./data.json').then(a => a.json())
    const data = await req.json();
    window.map = new Map()
    let li = `<tr><th>FirstName</th><th>LastName</th><th>Street</th><th>Address</th> <th>City</th><th>State</th><th>Email</th><th>Phone</th> <th colspan="2">Actions</th></tr>`;
    data.forEach((user) => {
      map.set(user.uuid, user)
      li += `<tr>
              <td>${user.first_name}</td>
              <td>${user.last_name} </td>
              <td>${user.street}</td>
              <td>${user.address}</td>
              <td>${user.city}</td>
              <td>${user.state}</td>
              <td>${user.email}</td>
              <td>${user.phone}</td>
              <td>
              <button onclick="('${user.uuid}')">Delete </button> 
              </td>
              <td>
               <button type="button" onclick="editCustomer('${user.uuid}')"> update </button> </td>
            </tr>`;
    });

    document.getElementById("users").innerHTML = li;
  }
  init()
} else {
  window.location.href = "/sunbase.html"


  // fetch("https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp")
  //   // Converting received data to JSON
  //   .then((response) => response.json())
  //   .then((json) => {

  //     // 2. Create a variable to store HTML table headers
  //     let li = `<tr><th>FirstName</th><th>LastName</th><th>Street</th><th>Address</th> <th>City</th><th>State</th><th>Email</th><th>Phone</th></tr>`;

  //     // 3. Loop through each data and add a table row
  //     json.forEach((user) => {
  //       li += `<tr>
  //         <td>${user.first_name}</td>
  //         <td>${user.last_name} </td>
  //         <td>${user.street}</td>
  //         <td>${user.address}</td>
  //         <td>${user.city}</td>
  //         <td>${user.state}</td>
  //         <td>${user.email}</td>
  //         <td>${user.phone}</td>
  //         <td>
  //         <button type="submit" >Edit</button>
  //         <button type="submit">Delete</button>

  //         </td>
  //       </tr>`;
  //     });
  //     document.getElementById("users").innerHTML = li;
  //   });

  function deletecustomer(uuid) {


    if (!confirm("Are you sure to delere ?")) return
    fetch(`https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=delete&uuid=${uuid}`, {
      method: 'POST',
      headers: {
        'Authorization': 'Bearear ${authToken}',

      }
    })
      .then(response => {
        if (response.status === 200) {
          alert('Customer deleted successfully!');
          loadCustomerList();
        } else if (response.status === 500) {
          alert('not deleted.');
        } else if (response.status === 400) {
          alert(' uuid ');
        } else {
          alert('Unexpected error.');
        }
      })
      .catch(error => {
        console.error('Error:', error);
        alert('An error occurred ');
      });

  }






  const form = document.querySelector(".registration-form");

  form.onsubmit = e => {
    console.log('submitted')
    e.preventDefault();
    const addFirstName = document.getElementById('firstName').value;
    const addLastName = document.getElementById('lastName').value;
    const addStreet = document.getElementById('street').value;
    const addAddress = document.getElementById('address').value;
    const addCity = document.getElementById('city').value;
    const addState = document.getElementById('state').value;
    const addEmail = document.getElementById('email').value;
    const addPhone = document.getElementById('phone').value;



    fetch('https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=create', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        "first_name": addFirstName,
        "last_name": addLastName,
        "street": addStreet,
        "address": addAddress,
        "city": addCity,
        "state": addState,
        "email": addEmail,
        "phone": addPhone
      }),
    })
      .then(response => {
        create - form
        if (response.status === 201) {
          alert('Customer created successfully!');
          init();
          document.getElementById('addCustomerForm').reset();
        } else {
          alert('Error: Unable to create customer.');
        }
      })
      .catch(error => {
        console.error('Error creating customer:', error);
        alert('An error occurred while creating the customer.');
      });

  }


  function updateCustomer() {
    fetch(`https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=get_customer&uuid=${userUUID}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        body: JSON.stringify()
      },
    })
      .then(response => {
        if (response.status === 200) {
          return response.json();
        } else {
          alert('Error: Unable to fetch existing customer data.');
        }
      })

  }
}

